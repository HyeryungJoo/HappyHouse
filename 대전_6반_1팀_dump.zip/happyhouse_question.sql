-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: localhost    Database: happyhouse
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `qnum` int NOT NULL AUTO_INCREMENT,
  `qmid` varchar(20) NOT NULL,
  `qtitle` varchar(45) NOT NULL,
  `qcontent` varchar(200) NOT NULL,
  `qcreatetime` datetime NOT NULL,
  `qmodifywriter` varchar(20) DEFAULT NULL,
  `qmodifytime` datetime DEFAULT NULL,
  `qLat` varchar(30) DEFAULT NULL,
  `qLng` varchar(30) DEFAULT NULL,
  `qDetailAddress` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`qnum`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (27,'ssafy','여기 병원 정밀 건강검진 되나요??','가격대도 궁금합니다.','2022-05-26 11:29:51',NULL,NULL,'37.534038525838106','126.95317094159077','서울 용산구 원효로4가 46'),(28,'ssafy','미술관 전시 볼만한가요?','집근처 다른 전시관도 추천해주세요','2022-05-26 11:30:39',NULL,NULL,'37.53800319757877','126.99884590070553','서울 용산구 한남동 743-28'),(29,'ssafy','여기 학교 축구부 있나요?','아들이 축구를 좋아해서 축구부있는 학교로 가려고합니다','2022-05-26 11:31:21',NULL,NULL,'37.552498187353514','126.96052668874559','서울 마포구 아현동 386-1'),(30,'ssafy','동네 근처 음악학원 추천해주세요','딸아이 보내려고 합니다.','2022-05-26 11:32:52',NULL,NULL,'37.51937889209382','126.98804333635519','서울 용산구 서빙고동 241-11'),(31,'ssafy','호캉스 가고싶은데~','요 호텔 1박에 얼마인가요?','2022-05-26 11:34:03',NULL,NULL,'37.52861911176779','126.99374375540434','서울 용산구 이태원동 22-2'),(32,'ssafy','닥터스트레인지 보고싶은데 사람 많나요??','많으면 내일 아침에 가야지!','2022-05-26 11:35:21',NULL,NULL,'37.533338295598384','126.960118171331','서울 용산구 한강로3가 16-7'),(33,'ssafy','이번주 주말에 남산등산 같이 가실분!','아침에 가려고 하는데 같이 가실분 있나요?','2022-05-26 11:36:17',NULL,NULL,'37.548355363297624','126.99124687014063','서울 용산구 용산동2가 산 1-3'),(34,'ssafy','아직도 비둘기 많나요 ㄷㄷ','조류공포증이라;;:!;!;','2022-05-26 11:37:26',NULL,NULL,'37.55324501087388','126.97295236343912','서울 용산구 동자동 47'),(35,'ssafy','대박 여기 카페 개맛있음','비건빵집인데 장난 아님;','2022-05-26 11:38:34',NULL,NULL,'37.57973057614875','127.00364536536311','서울 종로구 동숭동 199-51'),(36,'ssafy','한강 사람 많나요???','날씨가 좋아서 가고싶어요','2022-05-26 11:39:09',NULL,NULL,'37.52817663967169','126.93271466050952','서울 영등포구 여의도동 84-4'),(37,'ssafy','저 피자 살건데 같이 나눠드실분 있나요?','혼자먹기엔 양이 너무 많아서요ㅜ','2022-05-26 11:55:56',NULL,NULL,'37.529921168673326','126.99635706007618','서울 용산구 보광동 238-2'),(38,'ssafy7','용산맛집 추천해주세요!','다 좋아합니당','2022-05-26 12:57:17',NULL,NULL,'37.52979876205936','126.96450967801964','서울 용산구 한강로3가 40-999');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 16:30:07
