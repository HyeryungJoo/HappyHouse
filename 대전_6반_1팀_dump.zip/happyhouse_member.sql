-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: localhost    Database: happyhouse
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `mno` int NOT NULL AUTO_INCREMENT,
  `mid` varchar(20) DEFAULT NULL,
  `mpw` varchar(100) DEFAULT NULL,
  `mname` varchar(20) DEFAULT NULL,
  `memail` varchar(45) DEFAULT NULL,
  `mphone` varchar(11) DEFAULT NULL,
  `mrole` varchar(20) DEFAULT 'user',
  `mbnum` int DEFAULT NULL,
  `mSnsId` bigint DEFAULT NULL,
  `mLikeGu` varchar(45) DEFAULT NULL,
  `mLikeDong` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`mno`),
  UNIQUE KEY `mid_UNIQUE` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'testid','testpw','testname','test@naver.com','0102345678','user',NULL,NULL,NULL,NULL),(6,'test4444','$2a$10$A8XwQY3THarRTJmru8wIX.XUnDqB9/UItsdX222.K0EbLXiUUbOdW','test4444','test4444@naver.com','01044444444','user',NULL,NULL,NULL,NULL),(10,NULL,NULL,'한다빈',NULL,NULL,'user',NULL,2252963900,NULL,NULL),(11,'test1','$2a$10$gJ3apGaBuOBa4ksZFyFMTOGGU4FQ6Eipxqp6bFtefLi.HvzBbtqNu','test1','test1@naver.com','01011111111','user',NULL,NULL,'강남구','논현동'),(12,'ADMIN','$2a$10$LMiwEdpppB.P7dK2P70rZOBbqGGenkSzJAEHzMF0/8NP2MDLNj0qm','ADMIN','ADMIN@ssafy.com','01000000000','user',NULL,NULL,NULL,NULL),(13,'ssafy','$2a$10$hEodoL5AsWb6JOfAb19UiefbTHVtcJSIsQzYfBHI4DLbomFCRAMNG','ssafy','ssafy@ssafy.com','01044444444','user',NULL,NULL,NULL,NULL),(14,'ssafy2','$2a$10$vb4kwEFvCLEMx1yfsDHxzOsbkyMzpKLmAwsgAIhhD.wQiVlw3/WWq','ssafy2','ssafy2','ssafy2','user',NULL,NULL,NULL,NULL),(15,'ssafy3','$2a$10$aYATHT7PwLUO3B7ZPelygOIsxe/p2AKe.z/QK7ecZpL1HLhXwMwL2','ssafy3','ssafy3@ssafy.com','01033333333','user',NULL,NULL,NULL,NULL),(16,'ssafy6','$2a$10$SEopvBBP0lwQXE/L3/MkL.HrgpdWP/nyhPc/IUD7cGBYLiXX6lC0S','ssafy6','ssafy6@ssafy.com','01012345678','user',NULL,NULL,NULL,NULL),(18,'ssafy7','$2a$10$865MIIDW0CHOXkp7JyX1r.FA1.Fu/wT0vblNWbljCsWmcafErXYXW','ssafy7','ssafy7','ssafy7','user',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 16:30:08
